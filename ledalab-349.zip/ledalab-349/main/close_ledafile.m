function close_ledafile
global leda2

% Check for necessary fields before proceeding
if ~isfield(leda2, 'file') || ~isfield(leda2.file, 'open') || ~leda2.file.open
    disp('LEDA file is not open or missing file field.');
    return;
end

% Handle unsaved data
if isfield(leda2.file, 'changed') && leda2.file.changed && isfield(leda2, 'intern') && ~leda2.intern.batchmode
    choice = questdlg('Do you want to save the current file?', 'Save File', 'Yes', 'No', 'Cancel', 'Yes');
    if strcmp(choice, 'Yes')
        save_ledafile;
    elseif strcmp(choice, 'Cancel')
        return;
    end
end

% Clear file-dependent variables
if isfield(leda2, 'data') && isfield(leda2.data, 'events')
    leda2.data.events.event = [];
    leda2.data.events.N = 0;
end

if isfield(leda2, 'file')
    leda2.file.version = 0;
    leda2.file.date = 0;
end

try
    delete_fit(0);
catch err
    disp(['Error deleting fit: ', err.message]);
end

leda2.file.open = 0;
