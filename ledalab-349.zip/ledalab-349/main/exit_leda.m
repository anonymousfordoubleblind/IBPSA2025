function exit_leda
global leda2

% Attempt to close the LEDA file safely
try
    close_ledafile;
catch err
    disp(['Error closing file: ', err.message]);
    % Additional error handling can be added here
end

% Check if the file is still considered "open" and if so, return early
if isfield(leda2, 'file') && isfield(leda2.file, 'open') && leda2.file.open
    return; %closing failed
end

% Close the figure and proceed with cleanup
try
    delete(gcf);
catch err
    disp(['Error deleting figure: ', err.message]);
end

% Save LEDA memory and log the session closure
try
    save_ledamem;
    add2log(0,['<<<< ', datestr(now,31), ' Session closed'],1);
    add2log(0,' ',1);
catch err
    disp(['Error during session closure: ', err.message]);
end
