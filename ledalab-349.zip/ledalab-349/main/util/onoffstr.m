function str = onoffstr(bool)
if bool 
    str = 'on';
else
    str = 'off';
end
